# pomodoro
Pomodoro desktop app developed with [Electron](https://github.com/atom/electron)

<img src="https://raw.githubusercontent.com/VadimDez/pomodoro/master/app-screen.png" width="200">