/**
 * Created by Vadym Yatsyuk on 30/03/16
 */

module.exports = {
  sessionLength: 25,
  restLength: 5
};